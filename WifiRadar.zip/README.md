# Wi-Fi Radar

Visualisasi kekuatan sinyal Wi-Fi (bukan sistem tracking posisi).
Build: push ke GitHub -> Actions -> artifact `WifiRadar-debug` (APK).
