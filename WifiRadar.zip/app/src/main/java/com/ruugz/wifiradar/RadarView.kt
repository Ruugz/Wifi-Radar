package com.ruugz.wifiradar

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.sin

/** Warna = kekuatan sinyal. BUKAN jenis objek (manusia/hewan tidak bisa dideteksi dari Wi-Fi). */
enum class Strength(val label: String, val color: Int) {
    STRONG("Kuat", Color.parseColor("#22C55E")),
    MEDIUM("Sedang", Color.parseColor("#FACC15")),
    WEAK("Lemah", Color.parseColor("#EF4444"))
}

/** Kategori kekuatan sinyal. Hanya indikator relatif, BUKAN jarak. */
fun strengthOf(rssi: Int): Strength = when {
    rssi >= -60 -> Strength.STRONG
    rssi >= -75 -> Strength.MEDIUM
    else -> Strength.WEAK
}

/** Sinyal sangat lemah (mendekati batas jangkauan). */
const val EDGE_RSSI = -85

data class RadarBlip(val id: String, val strength: Strength, val edge: Boolean = false)

/**
 * Radar = visualisasi kekuatan sinyal.
 * - Titik: zona dari kategori sinyal; sudut & offset dari hash ID (estimasi visual, bukan arah/jarak asli).
 * - Huruf U/T/S/B di bezel luar = arah kompas HP (sensor), tidak terkait posisi titik hotspot.
 */
class RadarView(context: Context) : View(context) {

    enum class Mode { HOTSPOT, CONNECTED }

    private var mode = Mode.HOTSPOT
    private var blips: List<RadarBlip> = emptyList()
    private var connected: Strength? = null
    private var heading: Float? = null
    private var phase = 0f
    private val d = resources.displayMetrics.density

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.5f * d; color = Color.parseColor("#2A4A73")
    }
    private val boundaryPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f * d; color = Color.parseColor("#38BDF8")
        pathEffect = DashPathEffect(floatArrayOf(10 * d, 6 * d), 0f)
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 1f * d; color = Color.parseColor("#1B3050")
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#7C93B3"); textSize = 11f * d; textAlign = Paint.Align.CENTER
    }
    private val compassPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 14f * d; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sweepPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3500
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    fun setMode(m: Mode) { mode = m; invalidate() }
    fun setHotspots(list: List<RadarBlip>) { blips = list; invalidate() }
    /** null = data tidak tersedia */
    fun setConnected(s: Strength?) { connected = s; invalidate() }
    /** Arah HP terhadap utara magnetik (derajat). null = tidak tersedia. */
    fun setHeading(h: Float?) { heading = h; invalidate() }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); animator.start() }
    override fun onDetachedFromWindow() { animator.cancel(); super.onDetachedFromWindow() }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        val s = minOf(w, (340 * d).toInt())
        setMeasuredDimension(s, s)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        sweepPaint.shader = SweepGradient(
            w / 2f, h / 2f,
            intArrayOf(0x0022D3EE, 0x0022D3EE, 0x6622D3EE),
            floatArrayOf(0f, 0.8f, 1f)
        )
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy) - 22 * d

        fill.style = Paint.Style.FILL
        fill.alpha = 255
        fill.color = Color.parseColor("#0F1B2E")
        c.drawCircle(cx, cy, r, fill)
        for (i in 1..2) c.drawCircle(cx, cy, r * i / 3f, ringPaint)
        c.drawLine(cx - r, cy, cx + r, cy, linePaint)
        c.drawLine(cx, cy - r, cx, cy + r, linePaint)

        c.save()
        c.rotate(phase * 360f, cx, cy)
        c.drawCircle(cx, cy, r, sweepPaint)
        c.restore()

        // batas cakupan (visual)
        c.drawCircle(cx, cy, r, boundaryPaint)

        if (mode == Mode.HOTSPOT) drawHotspots(c, cx, cy, r) else drawConnected(c, cx, cy, r)
        drawCompass(c, cx, cy, r)
    }

    private fun drawCompass(c: Canvas, cx: Float, cy: Float, r: Float) {
        val h = heading ?: return
        val names = arrayOf("U", "T", "S", "B")   // Utara, Timur, Selatan, Barat
        val rr = r + 12 * d
        for (k in 0..3) {
            val theta = Math.toRadians((k * 90 - h - 90).toDouble())
            val x = cx + (cos(theta) * rr).toFloat()
            val y = cy + (sin(theta) * rr).toFloat() + compassPaint.textSize / 3f
            compassPaint.color = if (k == 0) Color.parseColor("#F87171") else Color.parseColor("#CBD5E1")
            c.drawText(names[k], x, y, compassPaint)
        }
    }

    private fun drawHotspots(c: Canvas, cx: Float, cy: Float, r: Float) {
        c.drawText("Kuat", cx, cy - r / 3f + 14 * d, textPaint)
        c.drawText("Sedang", cx, cy - 2 * r / 3f + 14 * d, textPaint)
        c.drawText("Lemah", cx, cy - r + 14 * d, textPaint)
        c.drawText("batas jangkauan sinyal", cx, cy + r - 20 * d, textPaint)
        c.drawText("posisi titik = estimasi visual", cx, cy + r - 7 * d, textPaint)

        for (b in blips) {
            val h = b.id.hashCode()
            val angle = Math.toRadians(((h and 0x7fffffff) % 360).toDouble())
            val j = ((h ushr 9) and 0xff) / 255f
            val frac = when {
                b.edge -> 0.88f + j * 0.08f
                b.strength == Strength.STRONG -> 0.08f + j * 0.22f
                b.strength == Strength.MEDIUM -> 0.38f + j * 0.24f
                else -> 0.70f + j * 0.16f
            }
            val x = cx + (cos(angle) * r * frac).toFloat()
            val y = cy + (sin(angle) * r * frac).toFloat()
            fill.color = b.strength.color
            fill.alpha = 70
            c.drawCircle(x, y, 11 * d, fill)
            fill.alpha = 255
            c.drawCircle(x, y, 5 * d, fill)
        }
        fill.alpha = 255
    }

    private fun drawConnected(c: Canvas, cx: Float, cy: Float, r: Float) {
        val s = connected
        val color = s?.color ?: Color.parseColor("#64748B")
        if (s != null) {
            for (i in 0..2) {
                val t = (phase + i / 3f) % 1f
                fill.color = color
                fill.alpha = ((1f - t) * 110).toInt()
                fill.style = Paint.Style.STROKE
                fill.strokeWidth = 2f * d
                c.drawCircle(cx, cy, r * t, fill)
            }
            fill.style = Paint.Style.FILL
            fill.alpha = 255
        }
        fill.color = color
        c.drawCircle(cx, cy, 10 * d, fill)
        c.drawText(s?.label ?: "Tidak tersedia", cx, cy + 30 * d, textPaint)
        c.drawText("statistik koneksi, bukan posisi", cx, cy + r - 7 * d, textPaint)
    }
}
