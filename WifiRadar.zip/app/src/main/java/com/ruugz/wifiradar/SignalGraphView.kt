package com.ruugz.wifiradar

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** Grafik RSSI beberapa detik terakhir (dBm). Hanya data sinyal, bukan posisi. */
class SignalGraphView(context: Context) : View(context) {

    private var data: List<Int> = emptyList()
    private val d = resources.displayMetrics.density

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f * d; color = Color.parseColor("#22D3EE")
    }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 1f * d; color = Color.parseColor("#1B3050")
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#7C93B3"); textSize = 10f * d
    }

    fun setData(list: List<Int>) { data = list; invalidate() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawLine(0f, h / 2f, w, h / 2f, grid)
        c.drawLine(0f, h - 1f, w, h - 1f, grid)

        if (data.size < 2) {
            text.textAlign = Paint.Align.CENTER
            c.drawText("Grafik sinyal: Tidak tersedia", w / 2f, h / 2f + 4 * d, text)
            return
        }
        var lo = data.min()
        var hi = data.max()
        if (hi - lo < 6) { val mid = (hi + lo) / 2; lo = mid - 3; hi = mid + 3 }

        val path = Path()
        val stepX = w / 29f   // 30 sampel terakhir
        val startX = w - stepX * (data.size - 1)
        data.forEachIndexed { i, v ->
            val x = startX + stepX * i
            val y = h - 6 * d - (v - lo).toFloat() / (hi - lo) * (h - 12 * d)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        c.drawPath(path, line)

        text.textAlign = Paint.Align.LEFT
        c.drawText("$hi dBm", 2 * d, 11 * d, text)
        c.drawText("$lo dBm", 2 * d, h - 3 * d, text)
    }
}
