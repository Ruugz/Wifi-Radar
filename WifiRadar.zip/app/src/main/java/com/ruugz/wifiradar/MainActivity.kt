package com.ruugz.wifiradar

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val disclaimer =
        "Radar menampilkan estimasi kekuatan sinyal. Posisi dan jarak perangkat bukan pengukuran sebenarnya."
    private val na = "Tidak tersedia"

    private lateinit var wifi: WifiManager
    private lateinit var radar: RadarView
    private lateinit var info: TextView
    private lateinit var btnHotspot: Button
    private lateinit var btnConnected: Button

    private var connectedMode = false
    private var latencyMs: Int? = null
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private val scanReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (!connectedMode) refreshHotspot()
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (connectedMode) {
                measureLatency()
                refreshConnected()
            } else {
                try { @Suppress("DEPRECATION") wifi.startScan() } catch (_: Exception) {}
                refreshHotspot()
            }
            handler.postDelayed(this, if (connectedMode) 5000L else 15000L)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B1220"))
            setPadding(dp(16), dp(32), dp(16), dp(12))
        }

        root.addView(TextView(this).apply {
            text = "Wi-Fi Radar"
            textSize = 22f
            setTextColor(Color.WHITE)
        })

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, dp(8))
        }
        btnHotspot = Button(this).apply { text = "Hotspot Radar" }
        btnConnected = Button(this).apply { text = "Connected Radar" }
        val bp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        row.addView(btnHotspot, bp)
        row.addView(btnConnected, LinearLayout.LayoutParams(bp))
        root.addView(row)

        radar = RadarView(this)
        root.addView(radar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.CENTER_HORIZONTAL })

        info = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#CBD5E1"))
            setPadding(0, dp(12), 0, dp(8))
        }
        root.addView(ScrollView(this).apply { addView(info) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        root.addView(TextView(this).apply {
            text = disclaimer
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#7C93B3"))
        })

        setContentView(root)

        btnHotspot.setOnClickListener { setMode(false) }
        btnConnected.setOnClickListener { setMode(true) }
        setMode(false)
    }

    private fun setMode(connected: Boolean) {
        connectedMode = connected
        radar.setMode(if (connected) RadarView.Mode.CONNECTED else RadarView.Mode.HOTSPOT)
        btnHotspot.alpha = if (connected) 0.5f else 1f
        btnConnected.alpha = if (connected) 1f else 0.5f
        handler.removeCallbacks(tick)
        if (hasPerm()) handler.post(tick) else showNoPerm()
    }

    private fun hasPerm() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun showNoPerm() {
        radar.setHotspots(emptyList()); radar.setConnected(null)
        info.text = "$na\n\nAndroid mewajibkan izin lokasi untuk membaca data Wi-Fi. " +
            "Lokasi tidak dipakai untuk menentukan posisi perangkat."
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(scanReceiver, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION))
        if (hasPerm()) { handler.removeCallbacks(tick); handler.post(tick) }
        else requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        try { unregisterReceiver(scanReceiver) } catch (_: Exception) {}
        super.onPause()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (hasPerm()) { handler.removeCallbacks(tick); handler.post(tick) } else showNoPerm()
    }

    // ---------- Hotspot Radar ----------

    private fun band(freq: Int) = when (freq) {
        in 2400..2500 -> "2.4 GHz"
        in 4900..5900 -> "5 GHz"
        in 5925..7125 -> "6 GHz"
        else -> na
    }

    private fun refreshHotspot() {
        if (!hasPerm()) { showNoPerm(); return }
        if (!wifi.isWifiEnabled) {
            radar.setHotspots(emptyList())
            info.text = "$na\n\nWi-Fi sedang mati."
            return
        }
        val results = try { wifi.scanResults } catch (_: SecurityException) { emptyList() }
            .filter { !it.BSSID.isNullOrEmpty() }
            .distinctBy { it.BSSID }
            .sortedByDescending { it.level }
            .take(30)

        radar.setHotspots(results.map { RadarBlip(it.BSSID, strengthOf(it.level)) })

        if (results.isEmpty()) { info.text = "$na\n\nBelum ada hasil pemindaian."; return }
        val sb = StringBuilder("Jaringan terdeteksi: ${results.size}\n\n")
        for (r in results) {
            val name = if (r.SSID.isNullOrEmpty()) "Jaringan tersembunyi" else r.SSID
            sb.append("• $name\n   ${strengthOf(r.level).label} · ${r.level} dBm · ${band(r.frequency)}\n")
        }
        sb.append("\nKategori Kuat/Sedang/Lemah hanyalah indikator relatif, bukan jarak.")
        info.text = sb.toString()
    }

    // ---------- Connected Radar ----------

    private fun measureLatency() {
        io.execute {
            val ms: Int? = try {
                val s = Socket()
                val t0 = System.nanoTime()
                s.connect(InetSocketAddress("1.1.1.1", 53), 1500)
                val v = ((System.nanoTime() - t0) / 1_000_000).toInt()
                s.close()
                v
            } catch (_: Exception) { null }
            runOnUiThread { latencyMs = ms }
        }
    }

    private fun refreshConnected() {
        if (!hasPerm()) { showNoPerm(); return }
        @Suppress("DEPRECATION")
        val ci = try { wifi.connectionInfo } catch (_: Exception) { null }
        val connectedOk = wifi.isWifiEnabled && ci != null && ci.networkId != -1

        if (!connectedOk) {
            radar.setConnected(null)
            info.text = "$na\n\nPerangkat tidak terhubung ke Wi-Fi."
            return
        }
        val ssid = ci!!.ssid?.trim('"')?.takeIf { it.isNotEmpty() && it != "<unknown ssid>" } ?: na
        val rssi = ci.rssi.takeIf { it > -127 && it < 0 }
        val link = ci.linkSpeed.takeIf { it > 0 }
        val freq = ci.frequency.takeIf { it > 0 }
        val lat = latencyMs

        val sig = rssi?.let { strengthOf(it) }
        radar.setConnected(sig)

        // Ringkasan kualitas: yang terburuk dari data yang tersedia (RSSI & latensi)
        val latScore = lat?.let { if (it < 60) 0 else if (it < 150) 1 else 2 }
        val scores = listOfNotNull(sig?.ordinal, latScore)
        val quality = if (scores.isEmpty()) na else when (scores.max()) {
            0 -> "Baik"; 1 -> "Sedang"; else -> "Buruk"
        }

        info.text = buildString {
            append("Jaringan: $ssid\n")
            append("Kekuatan sinyal (RSSI): ${rssi?.let { "$it dBm (${strengthOf(it).label})" } ?: na}\n")
            append("Kecepatan link: ${link?.let { "$it Mbps" } ?: na}\n")
            append("Frekuensi: ${freq?.let { band(it) } ?: na}\n")
            append("Latensi (ke 1.1.1.1): ${lat?.let { "$it ms" } ?: na}\n")
            append("Kualitas koneksi: $quality\n\n")
            append("Ini statistik koneksi realtime, bukan koordinat atau jarak.")
        }
    }
}
