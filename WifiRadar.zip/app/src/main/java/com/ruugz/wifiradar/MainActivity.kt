package com.ruugz.wifiradar

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.sqrt

class MainActivity : Activity(), SensorEventListener {

    private val disclaimer =
        "Radar menampilkan estimasi kekuatan sinyal. Posisi dan jarak perangkat bukan pengukuran sebenarnya. Huruf arah mengikuti kompas HP, bukan arah hotspot. Warna = kekuatan sinyal, bukan jenis objek."
    private val na = "Tidak tersedia"

    private lateinit var wifi: WifiManager
    private lateinit var radar: RadarView
    private lateinit var info: TextView
    private lateinit var btnHotspot: Button
    private lateinit var btnConnected: Button
    private lateinit var headingText: TextView
    private lateinit var sensorManager: SensorManager
    private var rotSensor: Sensor? = null
    private var smoothHeading: Float? = null
    private lateinit var graph: SignalGraphView
    private lateinit var btnRefresh: Button
    private var accSensor: Sensor? = null
    private var accelEma = 0f
    private var lastMoveMs = 0L
    private var tickCount = 0
    private val samples = ArrayDeque<Int>()

    private var connectedMode = false
    private var latencyMs: Int? = null
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private val scanReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (!connectedMode) refreshHotspot()
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (connectedMode) {
                if (tickCount++ % 5 == 0) measureLatency()
                sampleRssi()
                refreshConnected()
            } else {
                startScanSafe()
                refreshHotspot()
            }
            handler.postDelayed(this, if (connectedMode) 1000L else 15000L)
        }
    }

    @Suppress("DEPRECATION")
    private fun startScanSafe() {
        try { wifi.startScan() } catch (_: Exception) {}
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        rotSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        accSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B1220"))
            setPadding(dp(16), dp(32), dp(16), dp(12))
        }

        root.addView(TextView(this).apply {
            text = "Wi-Fi Radar"
            textSize = 22f
            setTextColor(Color.WHITE)
        })

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, dp(8))
        }
        btnHotspot = Button(this).apply { text = "Hotspot" }
        btnConnected = Button(this).apply { text = "Connected" }
        val bp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        row.addView(btnHotspot, bp)
        row.addView(btnConnected, LinearLayout.LayoutParams(bp))
        btnRefresh = Button(this).apply { text = "Refresh" }
        row.addView(btnRefresh, LinearLayout.LayoutParams(bp))
        root.addView(row)

        radar = RadarView(this)
        root.addView(radar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.CENTER_HORIZONTAL })

        headingText = TextView(this).apply {
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#7C93B3"))
            text = "Arah HP: $na"
        }
        root.addView(headingText)

        root.addView(TextView(this).apply {
            textSize = 12f
            gravity = Gravity.CENTER
            text = legend()
        })

        graph = SignalGraphView(this)
        root.addView(graph, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(70)))

        info = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#CBD5E1"))
            setPadding(0, dp(12), 0, dp(8))
        }
        root.addView(ScrollView(this).apply { addView(info) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        root.addView(TextView(this).apply {
            text = disclaimer
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#7C93B3"))
        })

        setContentView(root)

        btnHotspot.setOnClickListener { setMode(false) }
        btnConnected.setOnClickListener { setMode(true) }
        btnRefresh.setOnClickListener {
            samples.clear(); graph.setData(emptyList()); tickCount = 0
            handler.removeCallbacks(tick)
            if (hasPerm()) handler.post(tick)
            else requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
        setMode(false)
    }

    private fun setMode(connected: Boolean) {
        connectedMode = connected
        samples.clear(); tickCount = 0
        graph.setData(emptyList())
        graph.visibility = if (connected) View.VISIBLE else View.GONE
        radar.setMode(if (connected) RadarView.Mode.CONNECTED else RadarView.Mode.HOTSPOT)
        btnHotspot.alpha = if (connected) 0.5f else 1f
        btnConnected.alpha = if (connected) 1f else 0.5f
        handler.removeCallbacks(tick)
        if (hasPerm()) handler.post(tick) else showNoPerm()
    }

    private fun hasPerm() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun showNoPerm() {
        radar.setHotspots(emptyList()); radar.setConnected(null)
        info.text = "$na\n\nAndroid mewajibkan izin lokasi untuk membaca data Wi-Fi. " +
            "Lokasi tidak dipakai untuk menentukan posisi perangkat."
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(scanReceiver, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION))
        val rs = rotSensor
        if (rs != null) sensorManager.registerListener(this, rs, SensorManager.SENSOR_DELAY_UI)
        else { radar.setHeading(null); headingText.text = "Arah HP: $na" }
        accSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        if (hasPerm()) { handler.removeCallbacks(tick); handler.post(tick) }
        else requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        sensorManager.unregisterListener(this)
        try { unregisterReceiver(scanReceiver) } catch (_: Exception) {}
        super.onPause()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (hasPerm()) { handler.removeCallbacks(tick); handler.post(tick) } else showNoPerm()
    }

    // ---------- Kompas & legenda ----------

    private fun legend(): SpannableStringBuilder {
        val sb = SpannableStringBuilder()
        fun item(text: String, color: Int) {
            val start = sb.length
            sb.append("● ")
            sb.setSpan(ForegroundColorSpan(color), start, start + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            val s2 = sb.length
            sb.append(text)
            sb.setSpan(ForegroundColorSpan(Color.parseColor("#CBD5E1")), s2, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        item("Sinyal kuat", Strength.STRONG.color); sb.append("    ")
        item("Sedang", Strength.MEDIUM.color); sb.append("    ")
        item("Lemah", Strength.WEAK.color)
        return sb
    }

    private fun dirName(deg: Float): String {
        val n = arrayOf("Utara", "Timur Laut", "Timur", "Tenggara", "Selatan", "Barat Daya", "Barat", "Barat Laut")
        return n[((deg + 22.5f) / 45f).toInt() % 8]
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            val mag = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
            accelEma = accelEma * 0.8f + abs(mag - 9.81f) * 0.2f
            if (accelEma > 0.5f) lastMoveMs = System.currentTimeMillis()
            return
        }
        if (e.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
        val rm = FloatArray(9)
        SensorManager.getRotationMatrixFromVector(rm, e.values)
        val o = FloatArray(3)
        SensorManager.getOrientation(rm, o)
        var az = Math.toDegrees(o[0].toDouble()).toFloat()
        if (az < 0) az += 360f
        val prev = smoothHeading
        val h = if (prev == null) az else {
            var diff = az - prev
            if (diff > 180f) diff -= 360f
            if (diff < -180f) diff += 360f
            (prev + diff * 0.15f + 360f) % 360f
        }
        smoothHeading = h
        radar.setHeading(h)
        headingText.text = "Arah HP: ${h.toInt()}° (${dirName(h)}) · utara magnetik, pegang HP mendatar"
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    // ---------- Hotspot Radar ----------

    private fun band(freq: Int) = when (freq) {
        in 2400..2500 -> "2.4 GHz"
        in 4900..5900 -> "5 GHz"
        in 5925..7125 -> "6 GHz"
        else -> na
    }

    private fun refreshHotspot() {
        if (!hasPerm()) { showNoPerm(); return }
        if (!wifi.isWifiEnabled) {
            radar.setHotspots(emptyList())
            info.text = "$na\n\nWi-Fi sedang mati."
            return
        }
        val raw = try { wifi.scanResults } catch (_: SecurityException) { null } ?: emptyList()
        val results = raw
            .filter { !it.BSSID.isNullOrEmpty() }
            .distinctBy { it.BSSID }
            .sortedByDescending { it.level }
            .take(30)

        radar.setHotspots(results.map { RadarBlip(it.BSSID, strengthOf(it.level), it.level < EDGE_RSSI) })

        if (results.isEmpty()) { info.text = "$na\n\nBelum ada hasil pemindaian."; return }
        val sb = StringBuilder("Jaringan terdeteksi: ${results.size}\n\n")
        for (r in results) {
            val name = if (r.SSID.isNullOrEmpty()) "Jaringan tersembunyi" else r.SSID
            sb.append("• $name\n   ${strengthOf(r.level).label} · ${r.level} dBm · ${band(r.frequency)}${if (r.level < EDGE_RSSI) " · tepi jangkauan" else ""}\n")
        }
        sb.append("\nKategori Kuat/Sedang/Lemah hanyalah indikator relatif, bukan jarak.")
        info.text = sb.toString()
    }

    // ---------- Connected Radar ----------

    private fun phoneMoving() = System.currentTimeMillis() - lastMoveMs < 2500

    private fun sampleRssi() {
        if (!hasPerm()) return
        if (phoneMoving()) { samples.clear(); graph.setData(emptyList()); return }
        val ci = getConnInfo() ?: return
        val rssi = ci.rssi
        if (rssi > -127 && rssi < 0) {
            samples.addLast(rssi)
            while (samples.size > 30) samples.removeFirst()
        }
        graph.setData(samples.toList())
    }

    private fun motionStatus(): String {
        if (phoneMoving()) return "HP sedang bergerak, hasil tidak valid"
        if (samples.size < 10) return "Mengumpulkan data (${samples.size}/10)"
        val mean = samples.average()
        val sd = sqrt(samples.map { (it - mean) * (it - mean) }.average())
        val lvl = when {
            sd < 1.5 -> "Tenang"
            sd < 3.0 -> "Sedang"
            else -> "Tinggi"
        }
        val note = if (accSensor == null) " (validasi gerak HP: $na)" else ""
        return "$lvl (±${"%.1f".format(sd)} dB)$note"
    }


    private fun measureLatency() {
        io.execute {
            val ms: Int? = try {
                val s = Socket()
                val t0 = System.nanoTime()
                s.connect(InetSocketAddress("1.1.1.1", 53), 1500)
                val v = ((System.nanoTime() - t0) / 1_000_000).toInt()
                s.close()
                v
            } catch (_: Exception) { null }
            runOnUiThread { latencyMs = ms }
        }
    }

    @Suppress("DEPRECATION")
    private fun getConnInfo() = try { wifi.connectionInfo } catch (_: Exception) { null }

    private fun refreshConnected() {
        if (!hasPerm()) { showNoPerm(); return }
        val ci = getConnInfo()
        val connectedOk = wifi.isWifiEnabled && ci != null && ci.networkId != -1

        if (!connectedOk) {
            radar.setConnected(null)
            samples.clear(); graph.setData(emptyList())
            info.text = "$na\n\nPerangkat tidak terhubung ke Wi-Fi."
            return
        }
        val ssid = ci!!.ssid?.trim('"')?.takeIf { it.isNotEmpty() && it != "<unknown ssid>" } ?: na
        val rssi = ci.rssi.takeIf { it > -127 && it < 0 }
        val link = ci.linkSpeed.takeIf { it > 0 }
        val freq = ci.frequency.takeIf { it > 0 }
        val lat = latencyMs

        val sig = rssi?.let { strengthOf(it) }
        radar.setConnected(sig)

        // Ringkasan kualitas: yang terburuk dari data yang tersedia (RSSI & latensi)
        val latScore = lat?.let { if (it < 60) 0 else if (it < 150) 1 else 2 }
        val scores = listOfNotNull(sig?.ordinal, latScore)
        val quality = if (scores.isEmpty()) na else when (scores.max()) {
            0 -> "Baik"; 1 -> "Sedang"; else -> "Buruk"
        }

        info.text = buildString {
            append("Jaringan: $ssid\n")
            append("Kekuatan sinyal (RSSI): ${rssi?.let { "$it dBm (${strengthOf(it).label})" } ?: na}\n")
            append("Kecepatan link: ${link?.let { "$it Mbps" } ?: na}\n")
            append("Frekuensi: ${freq?.let { band(it) } ?: na}\n")
            append("Latensi (ke 1.1.1.1): ${lat?.let { "$it ms" } ?: na}\n")
            append("Kualitas koneksi: $quality\n")
            append("Perubahan sinyal 30 dtk: ${motionStatus()}\n\n")
            append("Perubahan sinyal bukan deteksi gerakan pasti dan tidak bisa membedakan manusia, hewan, atau benda. Ini statistik koneksi realtime, bukan koordinat atau jarak.")
        }
    }
}
