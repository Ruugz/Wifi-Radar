package com.ruugz.fakeinternet

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/** Bubble melayang di atas aplikasi lain. Ketuk = ON/OFF, seret = pindah. */
class OverlayService : Service() {
    companion object {
        @Volatile var active = false
    }

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val bg = GradientDrawable()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(2, Notif.build(this, "Pop-up melayang aktif"))
        if (bubble == null) addBubble()
        active = true
        return START_STICKY
    }

    private fun addBubble() {
        wm = getSystemService(WindowManager::class.java)
        bg.cornerRadius = 80f
        val tv = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(36, 22, 36, 22)
            background = bg
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 300
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    lp.x = startX + dx
                    lp.y = startY + dy
                    wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) toggle()
            }
            true
        }
        wm.addView(tv, lp)
        bubble = tv
        tick()
    }

    private fun toggle() {
        val ok = if (FakeServerService.running) FakeControl.disable(this) else FakeControl.enable(this)
        if (!ok) {
            Toast.makeText(
                this,
                "Izin WRITE_SECURE_SETTINGS belum diberikan (lihat layar utama)",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun tick() {
        val on = FakeServerService.running
        bubble?.text = if (on) "● INTERNET PALSU ON" else "○ INTERNET PALSU OFF"
        bg.setColor(if (on) Color.parseColor("#2E7D32") else Color.parseColor("#616161"))
        handler.postDelayed({ tick() }, 1000)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        active = false
        super.onDestroy()
    }
}
