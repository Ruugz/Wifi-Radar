package com.ruugz.fakeinternet

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var adb: TextView
    private lateinit var btnOverlay: Button
    private lateinit var btnHost: Button

    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()

    private fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { onClick(); refresh() }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        root.addView(TextView(this).apply {
            text = "Fake Internet"
            textSize = 24f
        })
        status = TextView(this).apply { setPadding(0, dp(12), 0, dp(8)) }
        root.addView(status)

        root.addView(btn("Aktifkan internet palsu") {
            if (!FakeControl.enable(this)) toast("Beri izin WRITE_SECURE_SETTINGS dulu (lihat perintah di bawah)")
            else toast("Aktif. Matikan lalu nyalakan lagi Wi-Fi agar sistem cek ulang.")
        })
        root.addView(btn("Matikan & kembalikan pengaturan") {
            FakeControl.disable(this)
            toast("Pengaturan dikembalikan")
        })
        btnOverlay = btn("") { toggleOverlay() }
        root.addView(btnOverlay)
        btnHost = btn("") { toggleHost() }
        root.addView(btnHost)
        root.addView(btn("Salin perintah ADB grant izin") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("adb", grantCmd()))
            toast("Disalin")
        })

        adb = TextView(this).apply {
            setTextIsSelectable(true)
            textSize = 12f
            setPadding(0, dp(16), 0, 0)
        }
        root.addView(adb)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun grantCmd() = "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS"

    private fun toggleOverlay() {
        if (OverlayService.active) {
            stopService(Intent(this, OverlayService::class.java))
        } else if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            toast("Izinkan 'tampil di atas aplikasi lain', lalu ketuk lagi")
        } else {
            startForegroundService(Intent(this, OverlayService::class.java))
        }
    }

    @Suppress("DEPRECATION")
    private fun wifiIp(): String {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ip = wm.connectionInfo.ipAddress
        return if (ip == 0) "" else "${ip and 0xff}.${ip shr 8 and 0xff}.${ip shr 16 and 0xff}.${ip shr 24 and 0xff}"
    }

    private fun toggleHost() {
        val next = if (FakeControl.host(this) == "127.0.0.1") wifiIp() else "127.0.0.1"
        if (next.isEmpty()) { toast("Sambungkan ke Wi-Fi dulu"); return }
        FakeControl.setHost(this, next)
        if (FakeServerService.running) FakeControl.enable(this)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun refresh() {
        val host = FakeControl.host(this)
        val url = "http://$host:${FakeServerService.PORT}/generate_204"
        status.text = buildString {
            appendLine("Server 204: " + if (FakeServerService.running) "AKTIF" else "mati")
            appendLine("Izin WRITE_SECURE_SETTINGS: " + if (CaptiveSettings.canWrite(this@MainActivity)) "ada" else "BELUM")
            appendLine("Izin pop-up: " + if (Settings.canDrawOverlays(this@MainActivity)) "ada" else "BELUM")
            append("URL cek: $url")
        }
        btnOverlay.text = if (OverlayService.active) "Pop-up melayang: matikan" else "Pop-up melayang: aktifkan"
        btnHost.text = "Host: $host (ketuk untuk ganti 127.0.0.1 / IP Wi-Fi)"
        adb.text = """
Langkah sekali saja (HP via ADB):
${grantCmd()}

Atau manual tanpa grant:
adb shell settings put global captive_portal_mode 1
adb shell settings put global captive_portal_use_https 0
adb shell settings put global captive_portal_http_url $url
adb shell settings put global captive_portal_https_url $url
adb shell settings put global captive_portal_fallback_url $url
adb shell settings put global captive_portal_other_fallback_urls $url

Reset manual:
adb shell settings delete global captive_portal_http_url
adb shell settings delete global captive_portal_https_url
adb shell settings delete global captive_portal_fallback_url
adb shell settings delete global captive_portal_other_fallback_urls
adb shell settings delete global captive_portal_use_https
adb shell settings delete global captive_portal_mode
""".trimIndent()
    }
}
