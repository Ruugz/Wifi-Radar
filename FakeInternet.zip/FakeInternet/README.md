# Fake Internet
Membuat Android menganggap Wi-Fi "punya internet" (tervalidasi) walau tanpa internet sungguhan,
untuk menguji aplikasi buatan sendiri. Dilengkapi bubble pop-up ON/OFF di atas aplikasi lain.

Build: push ke GitHub -> tab Actions -> unduh artifact app-debug-apk (APK).
Workflow otomatis mengekstrak file .zip di root repo dan mencari settings.gradle(.kts) sendiri.
